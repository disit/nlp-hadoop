

# Set these paths appropriately

HOME=./home
#USER=./hduser
#GATEHOME=./GATE
#PLUG=./plugins
#TTAG=./Tagger_TreeTagger
#RES=./resources
#TTBASE=./TreeTagger

OPTIONS="-token -lemma -sgml -no-unknown"

#TTBIN=${HOME}/${USER}/${GATEHOME}/${PLUG}/${TTAG}/${RES}/${TTBASE}/bin
#TTLIB=${HOME}/${USER}/${GATEHOME}/${PLUG}/${TTAG}/${RES}/${TTBASE}/lib
#TAGGER=${TTBIN}/tree-tagger
TAGGER=${HOME}/hduser/tree-tagger
#ABBR_LIST=${TTLIB}/italian-abbreviations
#PARFILE=${TTLIB}/italian.par
PARFILE=${HOME}/hduser/italian.par

$TAGGER $OPTIONS $PARFILE