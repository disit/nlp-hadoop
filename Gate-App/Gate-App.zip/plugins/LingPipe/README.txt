This directory contains wrappers for LingPipe from Alias-I, redistributed
under their royalty-free licence. Please consult their pages for more
information: http://alias-i.com/lingpipe/web/licensing.html (the royalty free
license is at http://alias-i.com/lingpipe/licenses/lingpipe-license-1.txt and
copied here as licence.txt).

The Royalty Free License has the requirement that data processed with LingPipe
be freely available as well if distribution happens. 

Thanks are due to the Alias-I folks, and to Niraj (from Sheffield), Katia and
Ekaterina (from OntoText) who did the integration.
